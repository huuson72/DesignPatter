	package SinhVien;
	
	import java.util.Date;
	public class SinhVien {
		 private int maSV;
		    private String hoTen;
		    private boolean gioiTinh;
		    private String ngaySinh;
	
		    public SinhVien(int studentID, String fullName, boolean isMale, String dateOfBirth) {
		        this.maSV = studentID;
		        this.hoTen = fullName;
		        this.gioiTinh = isMale;
		        this.ngaySinh = dateOfBirth;
		    }
	
		    @Override
		    public String toString() {
		        return "StudentID: " + maSV + ", FullName: " + hoTen + ", IsMale: " + gioiTinh + ", DateOfBirth: " + ngaySinh;
		    }
	
			public int getMaSV() {
				return maSV;
			}
	
			public void setMaSV(int maSV) {
				this.maSV = maSV;
			}
	
			public String getHoTen() {
				return hoTen;
			}
	
			public void setHoTen(String hoTen) {
				this.hoTen = hoTen;
			}
	
			public boolean isGioiTinh() {
				return gioiTinh;
			}
	
			public void setGioiTinh(boolean gioiTinh) {
				this.gioiTinh = gioiTinh;
			}
	
			public String getNgaySinh() {
				return ngaySinh;
			}
	
			public void setNgaySinh(String ngaySinh) {
				this.ngaySinh = ngaySinh;
			}
	
		    
	}
