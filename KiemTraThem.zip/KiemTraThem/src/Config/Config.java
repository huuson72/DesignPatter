package Config;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Config {
    private String url;

    public Config(String filePath) {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(filePath)) {
            props.load(fis);
            this.url = props.getProperty("database.url");

            // In URL ra để kiểm tra
            System.out.println("URL: " + this.url);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getUrl() {
        return url;
    }
}
