package ChuongTrinh;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Singleton.DatabaseConnection;
import SinhVien.SinhVien;	

public class ChuongTrinh {
    private List<SinhVien> studentCache = new ArrayList<>();
    private boolean cacheValid = false;

    public List<SinhVien> getAllStudents() {
        if (!cacheValid) {
            studentCache.clear();
            try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
                if (conn != null) {
                    String sql = "SELECT * FROM Students";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    ResultSet rs = pstmt.executeQuery();
                    while (rs.next()) {
                        int studentID = rs.getInt("StudentID");
                        String fullName = rs.getString("FullName");
                        boolean isMale = rs.getBoolean("IsMale");
                        String dateOfBirth = rs.getDate("DateOfBirth").toString();
                        studentCache.add(new SinhVien(studentID, fullName, isMale, dateOfBirth));
                    }
                    cacheValid = true;
                } else {
                    System.out.println("Connection is null");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return studentCache;
    }

    public void addStudent(String fullName, boolean isMale, String dateOfBirth) {
        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            String sql = "INSERT INTO Students (FullName, IsMale, DateOfBirth) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, fullName);
            pstmt.setBoolean(2, isMale);
            pstmt.setDate(3, java.sql.Date.valueOf(dateOfBirth));
            pstmt.executeUpdate();
            // Clear the cache and set it as invalid since we have added a new student
            studentCache.clear();
            cacheValid = false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ChuongTrinh manager = new ChuongTrinh();

        // In danh sách tất cả sinh viên ban đầu
        System.out.println("Danh sách tất cả sinh viên ban đầu:");
        for (SinhVien student : manager.getAllStudents()) {
            System.out.println(student);
        }

        // Bổ sung một sinh viên mới vào bảng
        manager.addStudent("Nguyễn Văn A", true, "2000-01-01");

        // In danh sách tất cả sinh viên sau khi bổ sung
        System.out.println("\nDanh sách tất cả sinh viên sau khi bổ sung:");
        for (SinhVien student : manager.getAllStudents()) {
            System.out.println(student);
        }
    }
}
